<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sales extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('Model_sales');
    }
    
	public function index()
	{
        $data['judul'] = 'Daftar Data Sales';
        $data['sales'] = $this->db->get('sales')->result_array();
        $this->load->view('sales/list',$data );
	}
    public function add()
    {
        
        if (isset($_POST['submit'])) {           
            $this->form_validation->set_rules('nama', 'Nama', 'required');            
            if ($this->form_validation->run() == FALSE)
            {
                $data['judul'] = 'Tambah Data Sales';
                $this->load->view('sales/add',$data );
            }
            else
            {
                $this->Model_sales->save();
                $this->session->set_flashdata('flash', 'Ditambahkan');
                redirect('sales');
            } 
        
         } else {            
            $data['judul'] = 'Tambah Data Sales';
            $data['sales'] = $this->db->get('sales')->result_array();
            $this->load->view('sales/add',$data );
            
        }  
        
    }
}
