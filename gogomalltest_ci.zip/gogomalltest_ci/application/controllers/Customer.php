<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer extends CI_Controller {

	function __construct() {
        parent::__construct();
        $this->load->model('Model_customer');
    }
    
	public function index()
	{
        $data['judul'] = 'Daftar Data Customer';
        $data['customer'] = $this->db->get('customer')->result_array();
        $this->load->view('customer/list',$data );
	}
    public function add()
    {
        
        if (isset($_POST['submit'])) {

                      
            $this->form_validation->set_rules('nama', 'Nama', 'required');            
            $this->form_validation->set_rules('no_telpon', 'No Telepon', 'required');                


            if ($this->form_validation->run() == FALSE)
            {

                $data['judul'] = 'Tambah Data Customer';
                $this->load->view('customer/add',$data );
            }
            else
            {
                $this->Model_customer->save();
                $this->session->set_flashdata('flash', 'Ditambahkan');
                redirect('customer');
            } 

            
         } else {

            
            $data['judul'] = 'Tambah Data Customer';
            $data['sales'] = $this->db->get('sales')->result_array();
            $this->load->view('customer/add',$data );
            
        }  
        
    }
}
