<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	
	public function index()
	{
        $data['judul'] = 'Tampilan List Customer dan Sales';
        $query = $this->db->query("SELECT tc.id, tc.no_telpon, tc.nama as namaC, ts.nama as namaS FROM customer as tc, sales as ts WHERE tc.id_sales = ts.id");
        $data['data']= $query->result_array();   
		$this->load->view('welcome_message', $data);
	}
}
