<?php

class Model_customer extends CI_Model {

    public $table ="customer";

    
    function save(){
        $data = array(
            'nama'              => $this->input->post('nama', TRUE),
            'no_telpon'            => $this->input->post('no_telpon', TRUE),
            'id_sales'          => $this->input->post('id_sales', TRUE),
            
            
        );
        
        $this->db->insert($this->table, $data);
        
    }
    


}
?>
