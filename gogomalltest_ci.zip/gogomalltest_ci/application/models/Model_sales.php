<?php

class Model_sales extends CI_Model {

    public $table ="sales";

    
    function save(){
        $data = array(
            'nama'              => $this->input->post('nama', TRUE),
            
        );
        
        $this->db->insert($this->table, $data);
        
    }
    


}
?>
